<?php

/**
 * $Id: $
 */

namespace Shopware\CustomModels\MoptPayonePaypal;

use Shopware\Components\Model\ModelRepository;

/**
 * Payone Paypal Repository
 */
class Repository extends ModelRepository
{
    
}
