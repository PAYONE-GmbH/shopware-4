//{block name="backend/mopt_config_payone/model/comboint"}
Ext.define('Shopware.apps.MoptConfigPayone.model.Comboint', {
  extend: 'Ext.data.Model',
  fields: [
    {
      name: 'display', 
      type: 'string'
    },
    {
      name: 'value', 
      type: 'integer'
    }
  ]
 
  
});
//{/block}