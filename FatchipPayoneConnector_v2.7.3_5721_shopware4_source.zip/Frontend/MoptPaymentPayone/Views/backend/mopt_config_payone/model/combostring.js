//{block name="backend/mopt_config_payone/model/combostring"}
Ext.define('Shopware.apps.MoptConfigPayone.model.Combostring', {
  extend: 'Ext.data.Model',
  fields: [
    {
      name: 'display', 
      type: 'string'
    },
    {
      name: 'value', 
      type: 'string'
    }
  ]
 
  
});
//{/block}