<?php

/**
 * $Id: $
 */

namespace Shopware\CustomModels\MoptPayoneCreditcardConfig;

use Shopware\Components\Model\ModelRepository;

/**
 * Payone Creditcard Config Repository
 */
class Repository extends ModelRepository
{
    
}